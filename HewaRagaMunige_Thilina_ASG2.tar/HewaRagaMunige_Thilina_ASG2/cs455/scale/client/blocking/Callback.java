package cs455.scale.client.blocking;

/**
 * User: thilinab
 * Date: 3/6/14
 * Time: 2:54 PM
 */
public interface Callback {
    public void invoke(byte[] data);
}
