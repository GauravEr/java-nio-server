package cs455.scale.server.task;

/**
 * Author: Thilina
 * Date: 3/1/14
 */
public interface Task {
    public void complete();
}
